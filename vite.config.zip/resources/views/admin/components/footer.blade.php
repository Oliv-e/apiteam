<link rel="stylesheet" href="{{asset('css/footer.css')}}">
<div class="footer">
    <span>SI KOPI Politeknik Negeri Pontianak 2024.</span>
</div>
