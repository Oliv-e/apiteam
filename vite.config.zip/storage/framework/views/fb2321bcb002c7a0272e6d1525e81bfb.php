<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title', 'MasterAdmin'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/master.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('css/assets/logopolnep.png')); ?>" type="image/x-icon">
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>
    <div class="master-content">
        <div class="side-content">
            <?php echo $__env->make('admin.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="main-content">
            <?php echo $__env->make('admin.components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="wrapper">
                <div class="main bg">
                </div>
                <div class="main content">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
            <?php echo $__env->make('admin.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
</html>
<?php /**PATH C:\xampp\htdocs\apiteam\resources\views/admin/master.blade.php ENDPATH**/ ?>