<?php echo $__env->make('Auth.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
<div>
    Login
</div>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\apiteam\resources\views/Auth/Page/login.blade.php ENDPATH**/ ?>