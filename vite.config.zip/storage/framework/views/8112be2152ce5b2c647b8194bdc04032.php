<link rel="stylesheet" href="<?php echo e(asset('css/navbar.css')); ?>">
<div class="navbar">
    <div class="nav-content">
        <h2><?php echo $__env->yieldContent('route', 'Routes'); ?></h2>
        <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
            <h3 class="success" id="session"><?php echo e(Session::get('success')); ?></h3>
        <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
        <?php $__sessionArgs = ['error'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
            <h3 class="error" id="session"><?php echo e(Session::get('error')); ?></h3>
        <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
        <h2>
            <?php if(Auth::check()): ?>
                <?php echo e(Auth::user()->data_pribadi->nama); ?>

            <?php endif; ?>
        </h2>
    </div>
</div>
<script>
    setTimeout(() => {
        document.getElementById('session').style.display = 'none';
    }, 2000);
</script>
<?php /**PATH C:\xampp\htdocs\apiteam\resources\views/admin/components/navbar.blade.php ENDPATH**/ ?>