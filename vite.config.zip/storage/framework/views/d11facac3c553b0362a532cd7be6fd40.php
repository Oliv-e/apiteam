<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>DATPUS</title>
</head>
<body>
    <?php if(Auth::check()): ?>
        <?php echo e(Auth::user()->id); ?>

        <h2>LOGGED IN</h2>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\apiteam\resources\views/welcome.blade.php ENDPATH**/ ?>