<?php $__env->startSection('title', 'Data Staff Admin'); ?>

<?php $__env->startSection('route', 'Data Staff Admin'); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .content {
            display: flex;
            flex-direction: column;
            height: 70vh;
        }
        table, td, th {
            border: 1px solid black;
            background: white;
        }
        .table-container {
            display: flex;
            flex-direction: column;
            overflow-y: auto;
            margin-top: 20px;
            width: 100%;
            flex: 1;
            padding: 10px;
        }
        td, th {
            padding: 8px;
            text-align: center
        }
        .content-link {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            padding: 0 10px;
        }
        .content-link a {
            background-color: white;
            padding: 10px;
            border-radius: 5px;
            text-decoration: none;
            color: black;
            border: 1px solid black;
            display: flex;
            align-items: center;
            gap: 10px
        }
        input {
            padding: 5px;
            border-radius: 5px;
            border: 1px solid black;
            text-align: center
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="content-link">
            <a href="<?php echo e(route('insert-staff')); ?>">
                <iconify-icon icon="ic:baseline-plus"></iconify-icon> Tambah Data Admin
            </a>
            <input type="text" id="search" placeholder="Ketikkan NAMA atau NIP">
        </div>

        <div class="table-container">
            <table id="dosen-table">
                <thead>
                    <tr>
                        <th>ID ADMIN</th>
                        <th>NAMA</th>
                        <th>NO HP</th>
                    </tr>
                </thead>
                <tbody id="dosen-table-body">
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($stf->id_admin); ?></td>
                            <td><?php echo e($stf->nama); ?></td>
                            <td><?php echo e($stf->no_hp); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        const searchInput = document.getElementById('search');
        const tableBody = document.getElementById('dosen-table-body');

        searchInput.addEventListener('keyup', () => {
            const searchValue = searchInput.value.toLowerCase();
            const rows = tableBody.getElementsByTagName('tr');

            for (let i = 0; i < rows.length; i++) {
                const row = rows[i];
                const columns = row.getElementsByTagName('td');

                let found = false;
                for (let j = 0; j < columns.length; j++) {
                    const column = columns[j];
                    if (column.textContent.toLowerCase().includes(searchValue)) {
                        found = true;
                        break;
                    }
                }

                if (found) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apiteam\resources\views/admin/staff/index.blade.php ENDPATH**/ ?>