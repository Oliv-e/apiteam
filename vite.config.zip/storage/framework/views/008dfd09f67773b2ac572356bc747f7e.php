<link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
<div class="footer">
    <span>SI KOPI Politeknik Negeri Pontianak 2024.</span>
</div>
<?php /**PATH C:\xampp\htdocs\apiteam\resources\views/admin/components/footer.blade.php ENDPATH**/ ?>