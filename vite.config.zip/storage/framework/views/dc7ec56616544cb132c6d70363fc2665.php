<?php $__env->startSection('title', 'Data Mahasiswa'); ?>

<?php $__env->startSection('route', 'Data Mahasiswa'); ?>
<?php $__env->startSection('css'); ?>
    <style>
        .content {
            display: flex;
            flex-direction: column;
            height: 70vh;
        }
        table, td, th {
            border: 1px solid black;
            background: white;
        }
        .table-container {
            display: flex;
            flex-direction: column;
            overflow-y: auto;
            margin-top: 20px;
            width: 100%;
            flex: 1;
            padding: 10px;
        }
        td, th {
            padding: 8px;
            text-align: center
        }
        .content-link {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            padding: 0 10px;
        }
        .content-link a {
            background-color: white;
            padding: 10px;
            border-radius: 5px;
            text-decoration: none;
            color: black;
            border: 1px solid black;
            display: flex;
            align-items: center;
            gap: 10px
        }
        input {
            padding: 5px;
            border-radius: 5px;
            border: 1px solid black;
            text-align: center
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="content-link">
            <a href="<?php echo e(route('insert-mahasiswa')); ?>">
                <iconify-icon icon="fluent-mdl2:insert-rows-below"></iconify-icon> Akun & Data Mahasiswa
            </a>
            <input type="text" id="search" placeholder="Ketikkan NAMA atau NIM">
        </div>

        <div class="table-container">
            <table id="mahasiswa-table">
                <thead>
                    <tr>
                        <th>NIM</th>
                        <th>NAMA</th>
                        <th>KODE PRODI</th>
                        <th>Semester</th>
                        <th>KELAS</th>
                        <th>NIP</th>
                        <th>NO HP</th>
                    </tr>
                </thead>
                <tbody id="mahasiswa-table-body">
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($mhs->nim); ?></td>
                            <td><?php echo e($mhs->nama); ?></td>
                            <td><?php echo e($mhs->kode_prodi); ?> || <?php echo e($mhs->prodi->nama_prodi); ?></td>
                            <td><?php echo e($mhs->semester); ?></td>
                            <td><?php echo e($mhs->kelas->abjad_kelas); ?></td>
                            <td><?php echo e($mhs->dosen_pembimbing->nip); ?></td>
                            <td><?php echo e($mhs->no_hp); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        const searchInput = document.getElementById('search');
        const tableBody = document.getElementById('mahasiswa-table-body');

        searchInput.addEventListener('keyup', () => {
            const searchValue = searchInput.value.toLowerCase();
            const rows = tableBody.getElementsByTagName('tr');

            for (let i = 0; i < rows.length; i++) {
                const row = rows[i];
                const columns = row.getElementsByTagName('td');

                let found = false;
                for (let j = 0; j < columns.length; j++) {
                    const column = columns[j];
                    if (column.textContent.toLowerCase().includes(searchValue)) {
                        found = true;
                        break;
                    }
                }

                if (found) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apiteam\resources\views/admin/mahasiswa/index.blade.php ENDPATH**/ ?>