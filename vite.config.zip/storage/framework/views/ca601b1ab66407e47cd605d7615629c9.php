<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
<div>
    <?php if($errors->has('err')): ?>
        <?php echo e($errors->first('err')); ?>

    <?php endif; ?>
    <h1>LOGIN</h1>
    <form action="<?php echo e(route('login')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="id">NIP/NIM/ID_ADMIN</label> <br>
        <input type="text" name="id" autocomplete="off" > <br>
        <label for="id">PASSWORD</label> <br>
        <input type="password" name="password" autocomplete="off"> <br>
        <input type="submit" value="LOGIN">
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Auth.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apiteam\resources\views/Auth/page/login.blade.php ENDPATH**/ ?>