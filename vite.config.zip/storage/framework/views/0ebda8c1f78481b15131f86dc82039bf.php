<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('route', 'Dashboard'); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <div class="card">
            <h2><?php echo e($data['mhs']); ?></h2>
            <span>Mahasiswa Aktif</span>
        </div>
        <div class="card">
            <h2><?php echo e($data['dsn']); ?></h2>
            <span>Dosen Aktif</span>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apiteam\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>