<?php $__env->startSection('title', 'Import Data Mahasiswa'); ?>

<?php $__env->startSection('css'); ?>
<style>
    * {
        padding: 0;
        margin: 0;
        box-sizing: border-box
    }
    th, td {
        border: 1px solid black;
        padding: 2px 5px
    }
    .navbar {
        padding: 10px;
        background: rgb(70, 255, 246);
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="navbar">
        <?php if(Auth::check()): ?>
            Halo, <?php echo e(Auth::user()->data_pribadi->nama); ?> <br> <a href="<?php echo e(route('logout')); ?>">LOG OUT</a>
        <?php endif; ?>
    </div>
    <h2>TEMPLATE EXCEL</h2>
    <table>
        <thead>
            <tr>
                <th>//</th>
                <th>A</th>
                <th>B</th>
                <th>C</th>
                <th>D</th>
                <th>E</th>
                <th>F</th>
                <th>G</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>NIM</td>
                <td>NAMA</td>
                <td>SEMESTER</td>
                <td>EMAIL</td>
                <td>KODE</td>
                <td>KELAS</td>
                <td>NO HP</td>
            </tr>
            <tr>
                <td>2</td>
                <td>32022160XX</td>
                <td>OXXXX</td>
                <td>X</td>
                <td>XX@gmail.com</td>
                <td>XX</td>
                <td>XX</td>
                <td>XXXXX</td>
            </tr>
        </tbody>
    </table>

    <form action="<?php echo e(route('insert-mahasiswa')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="file" name="file">
        <button type="submit">Import</button>
    </form>


    <a href="<?php echo e(route('dashboard')); ?>">Data Mahasiswa</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apiteam\resources\views/admin/mahasiswa/create.blade.php ENDPATH**/ ?>